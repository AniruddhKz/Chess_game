package com.aniruddha;

import java.util.Scanner;

public class ChessGame {

	public static void main(String[] args) {
		Board board=new Board();
		board.initialize();
		board.display();
		
		Scanner scan=new Scanner(System.in);
		
		while(!board.isGameOver()) {
			
			System.out.println(" enter move: ");
			String move=scan.nextLine();
			boolean moved=board.makeMove(move);
			
			if(!moved) {
				System.out.println(" invalid move:  ");
			}
			board.display();
			
		}
		scan.close();

	}

}
