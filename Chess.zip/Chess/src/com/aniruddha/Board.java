package com.aniruddha;

public class Board {
	
	private char[][]  board;
	
	public Board() {
		this.board=new char[8][8];
	
	}
	public void initialize() {
	for(int i=0; i<8; i++) {
		board[1][i]='P';
		board[6][i]='p';
	}
	
	char[] pieces= {'R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'};
	
	for(int i=0; i<8; i++) {
		board[0][i]=pieces[i];
		board[7][i]=(char)(pieces[i]+32); 
	}
}

public void display() {
	for(int i=0; i<8; i++) {
		for(int j=0;j<8;j++) {
			System.out.println((board[i][j]== '\u0000')? "." : board[i][j]+ " ");
		}
	
	System.out.println(i+1);

}
System.out.println("   a b c d e f g h");
}

public boolean isGameOver() {
	return true;
}

public boolean makeMove(String move) {
	
	int startX= move.charAt(0)-'a';
	int startY=7-(move.charAt(1)-'1');
	int endX=move.charAt(3)-'a';
	int endY=7-(move.charAt(4) - '1');
	
	
	
	if( startX<0  || 
		startX>7  ||
		startY<0  ||
		startY>7  ||
		endX<0    ||
		endX>7    ||
		endY<0    ||
		endY>7) {
		return false;
	}
	char piece=board[startY][startX];
	if(piece=='\u0000') {
		return false;
	}
	
	board[startY][startX]='\u0000';
	board[endY][endX]=piece;
	return true;
		
}

}





